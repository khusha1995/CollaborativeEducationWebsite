<?php 
	
if (isset($db))
{
	$sessname='w2kzx80_users_session';
	$cookname='w2kzx80_users_cookie';
	$users_ok=true;
	$login=$_POST['login'];
	$password=$_POST['password'];
	$cook=true;
	if (isset($_GET['logout']))
	{
		$db->query('UPDATE users SET `online`=0 WHERE hash="'.addslashes($_SESSION[$sessname]).'"');
		unset($_SESSION[$sessname]);
		
		setCookie($cookname,'',time()-24*3600,'/');
		unset($_COOKIE[$cookname]);
		$users_ok=false;
		
		$get='';
		foreach ($_GET as $gk=>$gv) if ($gk!='logout')
		{
			($get=='')?$get='?'.$gk.'='.urlencode($gv):$get.='&'.$gk.'='.urlencode($gv);
		}
		header('Location: http://jlearning.co.uk/templates/auth.php');
	}
	else
	{
		if (!isset($_SESSION['sesss_id']))
		{
			$_SESSION['sesss_id']=md5(date('d-G-i').$_SERVER["REMOTE_ADDR"]);
		}
		if (isset($_COOKIE[$cookname]))
		{
			$cook='yes';
		}
		if ((!isset($_SESSION[$sessname])) && (isset($_COOKIE[$cookname])))
		{
			$_SESSION[$sessname]=$_COOKIE[$cookname];
		}
		if (($login!="") && ($password!=""))
		{
			$md=md5($password.$login);
			$r=$db->query('SELECT * FROM users WHERE hash="'.$md.'" AND active=0');
			$user=$r->fetch_object();
			if (!$user)
			{
				unset($_SESSION[$sessname]);
				setCookie($cookname,'',time()-24*3600,'/');
				$users_ok=false;
			}
			else
			{
				$db->query('UPDATE users SET activity=NOW(),`online`=1 WHERE id='.$user->id);
			}
			$_SESSION[$sessname]=$md;
			if ($cook!='') setCookie($cookname,$md,time()+180000,'/');
		}
		else if (!isset($_SESSION[$sessname]))
		{
			setCookie($cookname,'',time()-24*3600,'/');	
			$users_ok=false;
		}
		else 
		{
			$s_md=addslashes($_SESSION[$sessname]);
			$r=$db->query('SELECT * FROM users WHERE hash="'.$s_md.'" AND active=0 AND `online`=1');
			$user=$r->fetch_object();
			if (!$user)
			{
				unset($_SESSION[$sessname]);
				setCookie($cookname,'',time()-24*3600,'/');
				$users_ok=false;
			}
			else
			{
				$_SESSION[$sessname]=$s_md;
				if ($cook!='') setCookie($cookname,$s_md,time()+180000,'/');
				$db->query('UPDATE users SET activity=NOW() WHERE id='.$user->id);
			}
		}
	}
	
	if ($users_ok)
	{
		foreach ($user as $k=>$v)
		{
			define('USER_'.strtoupper($k),$v);
			
		}
		define('USER_OK',true);
	}
	else
	{
		define('USER_OK',false);		
	}
	
	//privs
	global $_USER_PRIVS;
	$_USER_PRIVS=array();
	global $_USER_GROUPS;
	$_USER_GROUPS=array();
	$r=$db->query('SELECT * FROM users_privs');
	while ($f=$r->fetch_object())
	{
		$_USER_PRIVS[$f->name]=$f;
	}
	$r=$db->query('SELECT * FROM users_groups');
	while ($f=$r->fetch_object())
	{
		$_USER_GROUPS[$f->name]=$f;
	}
}
?>