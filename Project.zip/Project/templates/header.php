<?php
	if ($_SERVER['REQUEST_URI']=='/')
	{
		$_SESSION['catalog_cats']=array();
	}
	if (!isset($_SESSION['catalog_cats']))
	{
		$_SESSION['catalog_cats']=array();
	}
	
	if (isset($_GET['top']))
	{
		$r=$db->query('SELECT id, parent_txt FROM catalog_structure WHERE alias="top" AND lang="'.$_SESSION['language'].'"');
		$top=$r->fetch_assoc();
		
		$r=$db->query('SELECT * FROM catalog_structure WHERE (parent_id='.$top['id'].' OR parent_txt LIKE "'.$top['parent_txt'].'_'.$top['id'].'_%") AND alias="'.$db->escape_string($_GET['top']).'" AND lang="'.$_SESSION['language'].'"');
		if ($c=$r->fetch_assoc())
		{
			$csplit=preg_split('/_/uis',$c['parent_txt']);
			$lsplit=preg_split('/_/uis',$top['parent_txt']);
			$pids='';
			foreach ($csplit as $cs) if ($cs!='') ($pids=='')?$pids=$cs:$pids.=','.$cs; 
			$c['parent_aliases']=array();
			$r2=$db->query('SELECT id,alias,name FROM catalog_structure WHERE id IN ('.$pids.') ORDER BY FIELD(id,'.$pids.')');
			while ($c2=$r2->fetch_assoc())
			{
				$c['parent_aliases'][]=$c2['alias'];
				$c['parent_names'][]=$c2['name'];
			}
			$c['parent_aliases'][]=$c['id'];
			$c['parent_names'][]=$c['name'];
			
			if (count($csplit)-count($lsplit)==1)
			{
				$c['op']='and';
				$_SESSION['catalog_cats']['top_'.$c['parent_txt'].'_'.$c['id']]=$c;
				
				foreach ($_SESSION['catalog_cats'] as $sk=>$sv) if (preg_match('/^top.+/uis',$sk))
				{
					if ($sv['id']!=$c['id'])
					{
						unset($_SESSION['catalog_cats'][$sk]);
					}
				}
			}
			elseif (count($csplit)-count($lsplit)==3)
			{
				$c['op']='and';
				$_SESSION['catalog_cats']['top_'.$c['parent_txt'].'_'.$c['id']]=$c;
				foreach ($_SESSION['catalog_cats'] as $sk=>$sv) if (preg_match('/^top.+/uis',$sk))
				{
					if (!preg_match('/^top_'.preg_replace('/^('.$top['parent_txt'].'_'.$top['id'].'_[^_]+)_.+$/uis','$1',$c['parent_txt']).'_.+$/uis',$sk)) 
					{
						unset($_SESSION['catalog_cats'][$sk]);
					}
					else
					{
						if ((preg_match('/^top_'.$c['parent_txt'].'_'.$sv['id'].'$/uis',$sk))&&($sv['id']!=$c['id']))
						{
							unset($_SESSION['catalog_cats'][$sk]);
						}
					}
				}
			}
			elseif (count($csplit)-count($lsplit)==3)
			{
				$c['op']='and';
				$_SESSION['catalog_cats']['top_'.$c['parent_txt'].'_'.$c['id']]=$c;
			}
			
			foreach ($_SESSION['catalog_cats'] as $sk=>$sv) if (preg_match('/^left_/uis',$sk)) 
			{
				unset($_SESSION['catalog_cats'][$sk]);
			}
		}
	}
	if (isset($_GET['leftall']))
	{
		$r=$db->query('SELECT id, parent_txt FROM catalog_structure WHERE alias="left" AND lang="ru"');
		$left=$r->fetch_assoc();
		$r=$db->query('SELECT id, parent_txt FROM catalog_structure WHERE alias="left1" AND lang="ru"');
		$left1=$r->fetch_assoc();
		$r=$db->query('SELECT id, parent_txt FROM catalog_structure WHERE alias="left2" AND lang="ru"');
		$left2=$r->fetch_assoc();
		
		
		$r=$db->query('SELECT * FROM catalog_structure WHERE (parent_id='.$left['id'].' OR parent_txt LIKE "'.$left['parent_txt'].'_'.$left['id'].'_%") AND alias="'.$db->escape_string($_GET['leftall']).'" AND lang="ru"');
		if ($c=$r->fetch_assoc())
		{
			$csplit=preg_split('/_/uis',$c['parent_txt']);
			$lsplit=preg_split('/_/uis',$left['parent_txt']);
			$pids='';
			foreach ($csplit as $cs) if ($cs!='') ($pids=='')?$pids=$cs:$pids.=','.$cs; 
			$c['parent_aliases']=array();
			$r2=$db->query('SELECT id,alias,name FROM catalog_structure WHERE id IN ('.$pids.') ORDER BY FIELD(id,'.$pids.')');
			while ($c2=$r2->fetch_assoc())
			{
				$c['parent_aliases'][]=$c2['alias'];
				$c['parent_names'][]=$c2['name'];
			}
			$c['parent_aliases'][]=$c['id'];
			$c['parent_names'][]=$c['name'];
			
			if ((preg_match('/^'.$left2['parent_txt'].'_'.$left2['id'].'(_|$)/uis',$c['parent_txt']))&&(count($csplit)-count($lsplit)==2))
			{
				$c['op']='and';
				$_SESSION['catalog_cats']['left_'.$c['parent_txt'].'_'.$c['id']]=$c;
						
				$sids=array($c['id']);
					
				$rs=$db->query('SELECT * FROM catalog_structure WHERE parent_id='.$c['id']);
				while ($cs=$rs->fetch_assoc())
				{
					$sids[]=$cs['id'];
					$cs['op']='or3';
					$_SESSION['catalog_cats']['left_'.$cs['parent_txt'].'_'.$cs['id']]=$cs;
				}
				
				foreach ($_SESSION['catalog_cats'] as $sk=>$sv)
				{
					if (preg_match('/^left_'.$c['parent_txt'].'_/uis',$sk))
					{
						if (!in_array($sv['id'],$sids))
						{
							unset($_SESSION['catalog_cats'][$sk]);
						}
					}
				}
			}	
		}
	}
	if (isset($_GET['leftalln']))
	{
		$r=$db->query('SELECT id, parent_txt FROM catalog_structure WHERE alias="left" AND lang="ru"');
		$left=$r->fetch_assoc();
		$r=$db->query('SELECT id, parent_txt FROM catalog_structure WHERE alias="left1" AND lang="ru"');
		$left1=$r->fetch_assoc();
		$r=$db->query('SELECT id, parent_txt FROM catalog_structure WHERE alias="left2" AND lang="ru"');
		$left2=$r->fetch_assoc();
		
		
		$r=$db->query('SELECT * FROM catalog_structure WHERE (parent_id='.$left['id'].' OR parent_txt LIKE "'.$left['parent_txt'].'_'.$left['id'].'_%") AND alias="'.$db->escape_string($_GET['leftalln']).'" AND lang="ru"');
		if ($c=$r->fetch_assoc())
		{
			$csplit=preg_split('/_/uis',$c['parent_txt']);
			$lsplit=preg_split('/_/uis',$left['parent_txt']);
			$pids='';
			foreach ($csplit as $cs) if ($cs!='') ($pids=='')?$pids=$cs:$pids.=','.$cs; 
			$c['parent_aliases']=array();
			$r2=$db->query('SELECT id,alias,name FROM catalog_structure WHERE id IN ('.$pids.') ORDER BY FIELD(id,'.$pids.')');
			while ($c2=$r2->fetch_assoc())
			{
				$c['parent_aliases'][]=$c2['alias'];
				$c['parent_names'][]=$c2['name'];
			}
			$c['parent_aliases'][]=$c['id'];
			$c['parent_names'][]=$c['name'];
			
			if ((preg_match('/^'.$left2['parent_txt'].'_'.$left2['id'].'(_|$)/uis',$c['parent_txt']))&&(count($csplit)-count($lsplit)==2))
			{
				$c['op']='and';
				$_SESSION['catalog_cats']['left_'.$c['parent_txt'].'_'.$c['id']]=$c;
						
				$sids=array($c['id']);
					
				$rs=$db->query('SELECT * FROM catalog_structure WHERE parent_id='.$c['id']);
				while ($cs=$rs->fetch_assoc())
				{
					$sids[]=$cs['id'];
					$cs['op']='or3';
					if (isset($_SESSION['catalog_cats']['left_'.$cs['parent_txt'].'_'.$cs['id']])) unset($_SESSION['catalog_cats']['left_'.$cs['parent_txt'].'_'.$cs['id']]);
				}
				
				foreach ($_SESSION['catalog_cats'] as $sk=>$sv)
				{
					if (preg_match('/^left_'.$c['parent_txt'].'_/uis',$sk))
					{
						if (!in_array($sv['id'],$sids))
						{
							unset($_SESSION['catalog_cats'][$sk]);
						}
					}
				}
			}	
		}
	}
	if (isset($_GET['left']))
	{
		$r=$db->query('SELECT id, parent_txt FROM catalog_structure WHERE alias="left" AND lang="ru"');
		$left=$r->fetch_assoc();
		$r=$db->query('SELECT id, parent_txt FROM catalog_structure WHERE alias="left1" AND lang="ru"');
		$left1=$r->fetch_assoc();
		$r=$db->query('SELECT id, parent_txt FROM catalog_structure WHERE alias="left2" AND lang="ru"');
		$left2=$r->fetch_assoc();
		
		
		$r=$db->query('SELECT * FROM catalog_structure WHERE (parent_id='.$left['id'].' OR parent_txt LIKE "'.$left['parent_txt'].'_'.$left['id'].'_%") AND alias="'.$db->escape_string($_GET['left']).'" AND lang="ru"');
		if ($c=$r->fetch_assoc())
		{
			$csplit=preg_split('/_/uis',$c['parent_txt']);
			$lsplit=preg_split('/_/uis',$left['parent_txt']);
			$pids='';
			foreach ($csplit as $cs) if ($cs!='') ($pids=='')?$pids=$cs:$pids.=','.$cs; 
			$c['parent_aliases']=array();
			$r2=$db->query('SELECT id,alias,name FROM catalog_structure WHERE id IN ('.$pids.') ORDER BY FIELD(id,'.$pids.')');
			while ($c2=$r2->fetch_assoc())
			{
				$c['parent_aliases'][]=$c2['alias'];
				$c['parent_names'][]=$c2['name'];
			}
			$c['parent_aliases'][]=$c['id'];
			$c['parent_names'][]=$c['name'];
			
			if (preg_match('/^'.$left1['parent_txt'].'_'.$left1['id'].'(_|$)/uis',$c['parent_txt']))
			{
				if (count($csplit)-count($lsplit)==2)
				{
					if (!isset($_SESSION['catalog_cats']['left_'.$c['parent_txt'].'_'.$c['id']]))
					{
						$c['op']='or1';
						$_SESSION['catalog_cats']['left_'.$c['parent_txt'].'_'.$c['id']]=$c;
						
						foreach ($_SESSION['catalog_cats'] as $sk=>$sv)
						{
							if (preg_match('/^left_'.$c['parent_txt'].'_'.$c['id'].'_/uis',$sk))
							{
								unset($_SESSION['catalog_cats'][$sk]);
							}
						}
					}
					else
					{
						unset($_SESSION['catalog_cats']['left_'.$c['parent_txt'].'_'.$c['id']]);
						foreach ($_SESSION['catalog_cats'] as $sk=>$sv) if (preg_match('/^left_'.$c['parent_txt'].'_'.$c['id'].'_/uis',$sk))
						{
							unset($_SESSION['catalog_cats'][$sk]);
						}
					}
				}
				elseif (count($csplit)-count($lsplit)==3)
				{
					if (isset($_SESSION['catalog_cats']['left_'.$c['parent_txt']])) unset($_SESSION['catalog_cats']['left_'.$c['parent_txt']]);//=preg_replace('/^.+_([^_]+)$/uis','$1',$c['parent_txt']);
					//if (isset($_SESSION['catalog_cats_op']['left_'.$c['parent_txt']])) unset($_SESSION['catalog_cats_op']['left_'.$c['parent_txt']]);//='or2';
					
					$c['op']='or1';
					$_SESSION['catalog_cats']['left_'.$c['parent_txt'].'_'.$c['id']]=$c;
					
					foreach ($_SESSION['catalog_cats'] as $sk=>$sv) if ((preg_match('/^left_'.$c['parent_txt'].'_/uis',$sk))&&($sv['id']!=$c['id']))
					{
						unset($_SESSION['catalog_cats'][$sk]);
					}
				}
			}
			else
			{
				if (count($csplit)-count($lsplit)==2)
				{
					if (!isset($_SESSION['catalog_cats']['left_'.$c['parent_txt'].'_'.$c['id']]))
					{
						$c['op']='and';
						$_SESSION['catalog_cats']['left_'.$c['parent_txt'].'_'.$c['id']]=$c;
						
						$sids=array($c['id']);
					
						$rs=$db->query('SELECT * FROM catalog_structure WHERE parent_id='.$c['id']);
						while ($cs=$rs->fetch_assoc())
						{
							$sids[]=$cs['id'];
							$cs['op']='or3';
							$_SESSION['catalog_cats']['left_'.$cs['parent_txt'].'_'.$cs['id']]=$cs;
						}
						
						foreach ($_SESSION['catalog_cats'] as $sk=>$sv)
						{
							if (preg_match('/^left_'.$c['parent_txt'].'_/uis',$sk))
							{
								//if ((preg_match('/^left_'.$c['parent_txt'].'($|_)/uis',$sk))&&($sv!=$c['id'])) unset($_SESSION['catalog_cats'][$sk]);
								//if ($sv!=$c['id']) 
								if (!in_array($sv['id'],$sids))
								{
									unset($_SESSION['catalog_cats'][$sk]);
								}
							}
						}
					}
					else
					{
						unset($_SESSION['catalog_cats']['left_'.$c['parent_txt'].'_'.$c['id']]);
						foreach ($_SESSION['catalog_cats'] as $sk=>$sv) if (preg_match('/^left_'.$c['parent_txt'].'_'.$c['id'].'_/uis',$sk))
						{
							unset($_SESSION['catalog_cats'][$sk]);
						}
					}
				}
				elseif (count($csplit)-count($lsplit)==3)
				{
					if (!isset($_SESSION['catalog_cats']['left_'.$c['parent_txt'].'_'.$c['id']]))
					{
						$c['op']='or3';
						$_SESSION['catalog_cats']['left_'.$c['parent_txt'].'_'.$c['id']]=$c;
						foreach ($_SESSION['catalog_cats'] as $sk=>$sv) if (preg_match('/^left.+/uis',$sk))
						{
							if (preg_match('/^left_'.preg_replace('/^('.$left['parent_txt'].'_'.$left['id'].'_[^_]+)_.*$/uis','$1',$c['parent_txt']).'_/uis',$sk))
							{
								if (!preg_match('/^left_'.$c['parent_txt'].'(_.+$|$)/uis',$sk)) 
								{
									unset($_SESSION['catalog_cats'][$sk]);
								}
							}
						}
					}
					else
					{
						unset($_SESSION['catalog_cats']['left_'.$c['parent_txt'].'_'.$c['id']]);
					}
				}
			}
		}	
	}	
?>	
<!DOCTYPE html>
<head>
	<link href='https://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500italic,500,700,700italic,900,900italic&subset=latin,cyrillic-ext,cyrillic' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="/templates/css/style.css" />
	<script type="text/javascript" src="/templates/js/jquery.js"></script>
	<link type="text/css" rel="stylesheet" href="/templates/lightslider/css/lightslider.css" />           
	<script type="text/javascript" src="/templates/lightslider/js/lightslider.js"></script>
</head>
<body>
<!-- Yandex.Metrika counter -->
<script type="text/javascript">
    (function (d, w, c) {
        (w[c] = w[c] || []).push(function() {
            try {
                w.yaCounter38337760 = new Ya.Metrika({
                    id:38337760,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true
                });
            } catch(e) { }
        });

        var n = d.getElementsByTagName("script")[0],
            s = d.createElement("script"),
            f = function () { n.parentNode.insertBefore(s, n); };
        s.type = "text/javascript";
        s.async = true;
        s.src = "https://mc.yandex.ru/metrika/watch.js";

        if (w.opera == "[object Opera]") {
            d.addEventListener("DOMContentLoaded", f, false);
        } else { f(); }
    })(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/38337760" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-80493360-1', 'auto');
  ga('send', 'pageview');

</script>


	<div id="all">
		<div id="header">
			<div id="header_topright">
				<div id="langs">
					<div class="all">
						<?php
							$r=$db->query('SELECT * FROM langs WHERE active=0 ORDER BY main DESC, prior');
							while ($l=$r->fetch_assoc()) //if ($l['code']!=$_SESSION['language'])
							{
								echo '<div class="li"><a href="/index.php?lang='.$l['code'].'">'.ucfirst($l['code']).'</a></div>';
							}
						?>
					</div>
					<?php
						echo '<div class="active">'.ucfirst($_SESSION['language']).'</div>';
					?>
				</div>
				<div id="currencies">
					<div class="all">
						<?php
							$r=$db->query('SELECT * FROM currency WHERE active=0 ORDER BY main DESC, prior');
							while ($l=$r->fetch_assoc()) if ($l['id']!=$_SESSION['currency']['id'])
							{
								echo '<div class="li"><a href="/index.php?currency='.$l['id'].'">'.$l['name'].'</a></div>';
							}
						?>
					</div>
					<?php
						echo '<div class="active">'.$_SESSION['currency']['name'].'</div>';
					?>
				</div>
				<!--
				<div id="loginmenu">
					<div class="li"><a href=""><?=l('Войти')?></a></div>
					<div class="li"><a href=""><?=l('Регистрация')?></a></div>
				</div>
				!-->
			</div>
			<div id="phone">
				<span><?=l('Телефон')?></span>
			</div>
		</div>
		<div class="clear"></div>
		<div id="header2">
			<div class="center">
				<div id="logo">
					<a href="/"><img src="/templates/images/<?=file_exists(ROOT.'/templates/images/logo_'.$_SESSION['language'].'.png')?'logo_'.$_SESSION['language'].'.png':'logo_ro.png'?>"/></a>
				</div>
				<?php
					if (count($_TRASH)<1)
					{
						echo '<div id="trash" class="empty">
								<div class="empty">'.l('В корзине нет товаров').'</div>
								<div class="full"><div class="count">0</div>0 '.$_SESSION['currency']['code'].'</div>
							</div>';
					}
					else
					{
						$cnt=0;
						$sum=0;
						foreach ($_TRASH as $t) 
						{
							$cnt+=$t['count'];
							$sum+=currency_convert($t['price']*$t['count'],$t['currency'],$_SESSION['currency']['id']);
						}
						echo '<div id="trash" class="full">
								<div class="empty">'.l('В корзине нет товаров').'</div>
								<div class="full"><div class="count">'.count($_TRASH).'</div><span class="sum">'.floor($sum).' '.$_SESSION['currency']['code'].'</span></div>
							</div>';
					}
				?>
				<div id="search">
					<form action="/templates/catalog.php" method="get">
						<input type="text" name="search" value="<?=$_GET['search']?>"/>
						<input type="image" src="/templates/images/search_submit.png"/>
					</form>
					<div id="search_requests">
						<?php
							$pa=preg_split('/:/uis',l('Популярные запросы'),-1,PREG_SPLIT_NO_EMPTY);
							if (isset($pa[1]))
							{
								echo $pa[0].': ';
								$sa=preg_split('/,/uis',$pa[1],-1,PREG_SPLIT_NO_EMPTY);
								$sk=0;
								foreach ($sa as $s)
								{
									$sk++;
									if ($sk!=1) echo ', ';
									$s=preg_replace('/(^[ ]+|[ ]+$)/uis','',$s);
									echo '<a href="/templates/catalog.php?search='.urlencode($s).'">'.$s.'</a>';
								}
							}
						?>
					</div>
				</div>
				
			</div>
		</div>
		<div class="clear"></div>
		<div id="header3">
			<div class="left">
				<div id="order_status_button"><?=l('Проверить статус заказа')?></div>
			</div>
			<div id="userinfo">
				<?php
					if (USER_OK)
					{
						((USER_IMG=='')||(!file_exists(ROOT.'/users/'.USER_IMG)))?$img='nophoto.png':$img=USER_IMG;
						echo '<table cellspacing="1px" cellpadding="0px">
								<tr>
									<td class="icos" rowspan="2">
										<a href=""><img src="/templates/images/ico_brilliant.png"/></a>
										<a href="/templates/lc_index.php"><img src="/templates/images/ico_settings.png"/></a>
										<a href="/templates/lc_wish.php"><img src="/templates/images/ico_wish.png"/></a>
									</td>
									<td rowspan="2" class="user_ico"><img src="/img.php?w=50&h=50&img=users/'.urlencode($img).'"/></td>
									<td class="user_name">'.USER_NAME.'</td>
								</tr>
								<tr>
									<td class="user_logout"><a href="/?logout=1">'.l('Выйти').'</a></td>
								</tr>
							</table>';
					}
					else
					{
						?>

						<div id="loginmenu">
							<div class="li"><a href="" class=" loginlink"><?=l('Войти')?></a></div>
							<div class="li"><a href="" class=" registerlink"><?=l('Регистрация')?></a></div>
						</div>
						<?php
					}
				?>
			</div>
			<div id="slider">
				<ul id="sliderul">
					<?php
						if (USER_OK)
						{
							$r=$db->query('SELECT * FROM messages WHERE (user_id=0 OR user_id='.USER_ID.') AND expire>=NOW() AND date<=NOW() ORDER BY date DESC');
						}
						else
						{
							$r=$db->query('SELECT * FROM messages WHERE user_id=0 AND expire>=NOW() AND date<=NOW() ORDER BY date DESC');
						}	
						while ($m=$r->fetch_assoc())
						{
							echo '<li><div class="myslide">'.$m['text'].'</div></li>';
						}
					?>
				</ul>
			</div>
		</div>
		<div class="clear"></div>
		
		<div id="content">
			<table cellspacing="0px" cellpadding="0px">
				<tr>
					<td class="leftmenu">
						<div class="leftmenu_content">
							<div class="leftmenu_item clicker create last p1"><a href=""><?=l('Создай свой дизайн')?></a></div>
						<?php
							$r=$db->query('SELECT catalog_structure.id, catalog_structure.alias, catalog_structure.name, catalog_structure.parent_txt FROM catalog_structure WHERE parent_id IN (SELECT id FROM catalog_structure WHERE alias="left1" AND lang="ru") AND lang="ru" ORDER BY prior');
							$rn=0;
							$leftsubmenu='<div class="leftsubmenu"><div class="group">';
							while ($c=$r->fetch_assoc())
							{
								$rn++;
								($rn==$r->num_rows)?$class=' last ':$class='';
								//if (in_array($c['id'],$_SESSION['catalog_cats'])) $class.=' active ';
								$sclass='';
								foreach ($_SESSION['catalog_cats'] as $sk=>$sv)
								{
									if (preg_match('/^left_'.$c['parent_txt'].'_'.$c['id'].'($|_)/uis',$sk))
									{
										$sclass='active';
										$class.=' active';
									}
								}
								echo '<div class="leftmenu_item clicker '.$class.' p2"><div class="submenu">';
								$allf=false;
								$r2=$db->query('SELECT * FROM catalog_structure WHERE parent_id='.$c['id'].' ORDER BY prior');
								while ($c2=$r2->fetch_assoc())
								{
									if ($allf==false)
									{
										$class='';
										foreach ($_SESSION['catalog_cats'] as $sk=>$sv) if ($sv['id']==$c['id']) $class='active'; 
										echo '<div class="item all '.$class.'"><a href="/templates/catalog.php?left='.urlencode($c['alias']).'">'.l('Все').' '.$c['name'].'</a></div>';
										$allf=true;
									}
									$class='';
									foreach ($_SESSION['catalog_cats'] as $sk=>$sv) if ($sv['id']==$c2['id']) $class='active'; 
									echo '<div class="item '.$class.'"><a href="/templates/catalog.php?left='.urlencode($c2['alias']).'">'.$c2['name'].'</a></div>';
								}
								echo '</div>';
								echo '<a class="clicker_link" href="/templates/catalog.php?left='.urlencode($c['alias']).'">'.$c['name'].'</a></div>';
								//if ($sclass!='')
								//{
								//	$r2=$db->query('SELECT * FROM catalog_structure WHERE parent_id='.$c['id'].' ORDER BY prior');
								//	while ($c2=$r2->fetch_assoc())
								//	{
								//		(in_array($c2['id'],$_SESSION['catalog_cats']))?$class='active':$class='';
								//		$leftsubmenu.='<div class="item '.$class.'"><a href="/templates/catalog.php?left='.urlencode($c2['alias']).'">'.$c2['name'].'</a></div>';
								//	}
								//}
							}
							//$leftsubmenu.='</div><div class="group">';
							$r=$db->query('SELECT catalog_structure.id, catalog_structure.alias, catalog_structure.name, catalog_structure.parent_txt FROM catalog_structure WHERE parent_id IN (SELECT id FROM catalog_structure WHERE alias="left2" AND lang="ru") AND lang="ru" ORDER BY prior');
							$rn=0;
							while ($c=$r->fetch_assoc())
							{
								$rn++;
								($rn==$r->num_rows)?$class=' last ':$class='';
								//if (in_array($c['id'],$_SESSION['catalog_cats'])) $class.=' active ';
								$sclass='';
								foreach ($_SESSION['catalog_cats'] as $sk=>$sv)
								{
									if (preg_match('/^left_'.$c['parent_txt'].'_'.$c['id'].'($|_)/uis',$sk))
									{
										$sclass='active';
										$class.=' active';
									}
								}
								echo '<div class="leftmenu_item clicker '.$class.' p3"><a href="/templates/catalog.php?left='.urlencode($c['alias']).'">'.$c['name'].'</a></div>';
								if ($sclass!='')
								{
									$r2=$db->query('SELECT * FROM catalog_structure WHERE parent_id='.$c['id'].' ORDER BY prior');
									while ($c2=$r2->fetch_assoc())
									{
										$class='';
										foreach ($_SESSION['catalog_cats'] as $sk=>$sv) if ($sv['id']==$c2['id']) $class='active';
										$leftsubmenu.='<div class="item '.$class.'"><a href="/templates/catalog.php?left='.urlencode($c2['alias']).'">'.$c2['name'].'</a></div>';
									}
									$leftsubmenu.='<div class="selectors"><div class="all"><a href="/templates/catalog.php?leftall='.urlencode($c['alias']).'">'.l('Выбрать все').'</a></div><div class="none"><a href="/templates/catalog.php?leftalln='.urlencode($c['alias']).'">'.l('Снять все').'</a></div></div>';
								}
							}
							$leftsubmenu.='</div></div>';
						?>
						</div>
					</td>
					<td class="catalog_content">
						<?php
							$is_active='';
							foreach ($_SESSION['catalog_cats'] as $sk=>$sv) if (preg_match('/^top_/uis',$sk)) $is_active=' is_active ';
						?>
						<div class="description"></div>
						<div class="topmenu <?=$is_active?>">
							<?php
								$r=$db->query('SELECT catalog_structure.id, catalog_structure.alias, catalog_structure.name, catalog_structure.img, catalog_structure.parent_txt FROM catalog_structure WHERE parent_id IN (SELECT id FROM catalog_structure WHERE alias="top" AND lang="ru") AND lang="ru" ORDER BY prior');
								$rn=0;
								$topsubmenu='<div class="topsubmenu">';
								while ($c=$r->fetch_assoc())
								{
									$rn++;
									($rn==$r->num_rows)?$class=' last ':$class='';
									//if (in_array($c['id'],$_SESSION['catalog_cats'])) $class.=' active ';
									$sclass='';
									foreach ($_SESSION['catalog_cats'] as $sk=>$sv)
									{
										if (preg_match('/^top_'.$c['parent_txt'].'_'.$c['id'].'($|_)/uis',$sk))
										{
											$sclass='active';
											$class='active';
										}
									}
									echo '<div class="topmenu_item clicker '.$class.'"><div class="hover"></div><a href="/templates/catalog.php?top='.urlencode($c['alias']).'"><img src="/img.php?w=112&h=112&img='.urlencode('categories/'.$c['img']).'"/><br/>'.$c['name'].'</a></div>';
									
									if ($sclass!='')
									{
										$class='';
										foreach ($_SESSION['catalog_cats'] as $sk=>$sv) if ($sv['id']==$c['id']) $class='active';
										$topsubmenu.='<div class="submenu '.$sclass.'"><div class="group"><div class="item '.$class.'"><a href="/templates/catalog.php?top='.urlencode($c['alias']).'">'.l('Все').'</a></div></div>';
										$r2=$db->query('SELECT * FROM catalog_structure WHERE parent_id='.$c['id'].' ORDER BY prior');
										while ($c2=$r2->fetch_assoc())
										{
											$topsubmenu.='<div class="group">';
											$r3=$db->query('SELECT * FROM catalog_structure WHERE parent_id='.$c2['id'].' ORDER BY prior');
											while ($c3=$r3->fetch_assoc())
											{
												$class='';
												foreach ($_SESSION['catalog_cats'] as $sk=>$sv) if ($sv['id']==$c3['id']) $class='active';
												$topsubmenu.='<div class="item '.$class.'"><a href="/templates/catalog.php?top='.urlencode($c3['alias']).'">'.$c3['name'].'</a></div>';
											}
											$topsubmenu.='</div>';
										}
										$topsubmenu.='</div>';
									}
								}
								$topsubmenu.='</div>';
							?>
						</div>
						<?=$topsubmenu?>