var wx=0;
var wy=0;
var pchat=0;
var cy=400;
var cid=0;
var cxx=0;
var cyy=0;
var ctx,canvas,points,bufer,offset;
var action='up';
var pencil=2;
var eraser=10;
var mode='pencil';
var du='';
var window_focus = Math.floor(Date.now() / 1000);
var msgid=0;

function savecanvasstate()
{
	points = new Array();
	bufer = ctx.getImageData(0,0,canvas.width,canvas.height);
	var dataURL = canvas.toDataURL();
	if (du!=dataURL)
	{
		du=dataURL;
		$.ajax({
			url: '/templates/ajax_savecanvas.php',
			method:'post',
			data:{pchat:pchat,action:'image',params:dataURL}
		}).done(function(msg){
		});
	}
}
function updatecanvasdata()
{
	$.ajax({
		url: '/templates/ajax_canvas.php',
		method: 'post',
		data:{pchat:pchat,lastid:cid}
	}).done(function(msg){
		var aa=JSON.parse(msg);
		for (var x in aa)
		{
			if (aa[x].action=='erase')
			{
				ctx.fillStyle="#FFFFFF";
				ctx.fillRect(0,0,canvas.width,canvas.height);
				savecanvasstate();
			}
			else if	(aa[x].action=='image')
			{
				var img = new Image;
				img.onload = function(){
					ctx.drawImage(img,0,0,canvas.width,canvas.height); // Or at whatever offset you like
					savecanvasstate();
				};
				img.src = aa[x].params;
			}
		}
	});
}

function initcanvas()
{
	canvas=document.getElementById('draw');
	ctx = canvas.getContext('2d');
	ctx.lineWidth = pencil;
	offset = 0;
	ctx.shadowBlur = 0;
	ctx.shadowColor = "#000000";   //pencil colour
	ctx.shadowOffsetX = -offset;
	ctx.fillStyle="#FFFFFF";      //canvas background colour on refresh
	ctx.fillRect(0,0,canvas.width,canvas.height);
	points = new Array();
	bufer = ctx.getImageData(0,0,canvas.width,canvas.height);
	
	updatecanvasdata();
}

function mDown(e){
	action = "down";
	points.push([e.pageX-cxx,e.pageY-cyy]);
};
function mUp(e){
	action = "up";
	savecanvasstate();
};
function mMove(e){
	if (action == "down") {
		ctx.putImageData(bufer,0,0);
		points.push([e.pageX-cxx,e.pageY-cyy]);
		ctx.beginPath();
		ctx.moveTo(points[0][0]+offset, points[0][1]);
		for (i = 1; i < points.length; i++){
			ctx.lineTo(points[i][0]+offset,points[i][1]);
		}
		ctx.stroke();
	}
};

function resize()
{
	if (wy>900)
	{
		cy=400;
	}
	else if (wy>500)
	{
		cy=200;
	}
	else
	{
		cy=100;
	}
	cid=0;
	$('#whiteboard').css('height',cy+'px').html('<div id="ccontainer"><canvas width="'+parseInt(cy*2)+'px" height="'+cy+'px" id="draw"></canvas></div>');
	$('#chat').css('height',(wy-cy-39)+'px');
	if (wx<1000)
	{
		$('#center').css('width',wx+'px');
		if (wx>500)
		{
			$('#sendmsg').css('width',(wx-400)+'px');
			$('#accounts').css('height',(wy-cy)+'px').css('display','block');
			$('#chat').css('width',(wx-260)+'px');
		}
		else
		{
			$('#accounts').css('height',(wy-cy-90)+'px').css('display','none');
			$('#sendmsg').css('width',(wx-50)+'px');
			$('#chat').css('width',wx+'px');
		}
	}
	else
	{
		$('#center').css('width','1000px');
		$('#chat').css('width','740px');
		$('#sendmsg').css('width','600px');
		$('#accounts').css('height',(wy-cy)+'px').css('display','block');
	}
	cxx=$('#draw').offset().left;
	cyy=$('#draw').offset().top;	
	initcanvas();
}
function openfilesdialog(pchat)
{
	$('#iframe').attr('src', '/templates/fileshist.php?pchat='+pchat);
	$('#iframebg').show();
	//Delete in future builds-->window.open('/templates/fileshist.php?pchat='+pchat,'privatefiles_'+$(this).closest('.user').attr('user'),'status=no,resizable=yes,left=200,top=200,toolbar=no,menubar=no,scrollbars=no,location=no,directories=no,width=600,height=600,screenX=600,screenY=600'); 
	
}
function getusers()
{
	$.ajax({
		url: '/templates/ajax_accounts.php',
		method:'post',
		data:{pchat:pchat}
	}).done(function(msg){
		$('#accounts').html(msg);
		$('.useroptions .option[action=private]').click(function(){
			window.open('/templates/tchat.php?private='+$(this).closest('.user').attr('user'),'private_'+$(this).closest('.user').attr('user'));
		});
		$('.useroptions .option[action=sprivate]').click(function(){
			window.open('/templates/chat.php?private='+$(this).closest('.user').attr('user'),'private_'+$(this).closest('.user').attr('user'));
		});
		$('.useroptions .option[action=sendfile]').click(function(){
			openfilesdialog($(this).closest('.user').attr('user'));
		});
	});
}
function setprivate(s)
{
	pchat=s;
}
function submitmessage()
{
	$.ajax({
		url: '/templates/ajax_send.php',
		method: 'post',
		data:{msg:$('#sendmsg').val(),to:pchat}
	}).done(function(msg){
		$('#sendmsg').val('');
	});
}


$(document).ready(function(){
	
	wx=parseInt($(window).width());
	wy=parseInt($(window).height());
	resize();
	$(window).resize(function(){
		wx=parseInt($(window).width());
		wy=parseInt($(window).height());
		resize();
	});
	setInterval(function(){
		getusers();
	},4230);
	getusers();
	
	setInterval(function(){
		var focused=true;
		if (Math.floor(Date.now() / 1000)-window_focus>3) focused=false;
		$.ajax({
			url: '/templates/ajax_chat.php',
			method: 'post',
			data: {pchat:pchat,focused:focused}
		}).done(function(msg){
			if (msg=='offline') 
			{
				window.location.href='/';
			}
			else
			{
				$('#chat').html(msg);
				$('.message').each(function(){
					if (!$(this).hasClass('mine'))
					{
						var i=parseInt($(this).attr('msgid'));
						if (i>msgid)
						{
							msgid=i;
							document.getElementById('alrt').play();
						}
					}
				});
			}
		$('.foot').click(function() {
			if($('.foot').hasClass('slide-up')) {
				$('.foot').addClass('slide-down', 1000, 'easeOutBounce');
				$('.foot').removeClass('slide-up'); 
			} else {
				$('.foot').removeClass('slide-down');
				$('.foot').addClass('slide-up', 1000, 'easeOutBounce'); 
			}
		});
		$('.message').each(function(){
			var str = $(this).html();
			var regex = /\b((?:[a-z][\w-]+:(?:\/{1,3}|[a-z0-9%])|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}\/)(?:[^\s()<>]+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[{};:'".,<>?«»“”‘’]|\]|\?))/ig
			var replaced_text = str.replace(regex, "<a href='$1' target='_blank'>$1</a>");
			$(this).html(replaced_text);
		});
	/*HERE MORE CODE*/
	});		
	},1231);
		
		
	/*QUILL*/
	$('#pollSlider-button').click(function() {
    if($(this).css("margin-left") == "400px")
    {
        $('.container1').animate({"margin-left": '-=400'});
        $('#pollSlider-button').animate({"margin-left": '-=400'});
    }
    else
    {
        $('.container1').animate({"margin-left": '+=400'});
        $('#pollSlider-button').animate({"margin-left": '+=400'});
    }
    });
  
    var quill = new Quill('#editor-container', {
	  modules: {
	    toolbar: [
	      [{header: [1, 2, false]}],
	      ['bold', 'italic', 'underline'],
	      ['image', 'code-block'],
	      [{'list': 'ordered'}, {'list': 'bullet'}]
	    ]
	  },
	  placeholder: 'Need to make some notes? Type them here...\n\nTIPS:\n1. [Need to escape the code feature? Just press enter and then the button again]\n\n2. [Press the arrow again to close the notes, don\'t worry, they won\'t get deleted, ..unless you refresh the page]',
	  theme: 'snow'
	});
	/*QUILL*/
	
	$('#sendmsgbutton').click(function(){
		submitmessage();
	});
	
	
	$('#iframecontainer #close').click(function(){
		$('#iframebg').hide();
	});
	
	
	$('.openhistfiles').click(function(){
		openfilesdialog(pchat);
		//window.open($(this).attr('href'),$(this).attr('target'),'status=no,resizable=yes,left=200,top=200,toolbar=no,menubar=no,scrollbars=no,location=no,directories=no,width=600,height=600,screenX=600,screenY=600'); 
		return false;
	});
	
	$('#sendmsg').keypress(function (e) {
		if (e.which == 13) {
			submitmessage();
		}
	});
	

	initcanvas();
	$('body').mousemove(function(e){
		mMove(e);
		window_focus = Math.floor(Date.now() / 1000);
	});
	$('body').mouseup(function(e){
		mUp(e);
		window_focus = Math.floor(Date.now() / 1000);
	});
	$('body').mousedown(function(e){
		mDown(e);
		window_focus = Math.floor(Date.now() / 1000);
	});
	$('body').keydown(function(e){
		window_focus = Math.floor(Date.now() / 1000);
	});
	$('body').keyup(function(e){
		window_focus = Math.floor(Date.now() / 1000);
	});
	
	$('#drawfunctions .function.draw').click(function(){
		ctx.lineWidth = pencil;
		ctx.shadowColor = "#000000";
		$('#drawfunctions .function').removeClass('active');
		$(this).addClass('active');
	});
	$('#drawfunctions .function.erase').click(function(){
		ctx.lineWidth = eraser;
		ctx.shadowColor = "#ffffff";
		$('#drawfunctions .function').removeClass('active');
		$(this).addClass('active');
	});
	$('#drawfunctions .function.eraseall').click(function(){
		ctx.fillStyle="#FFFFFF";
		ctx.fillRect(0,0,canvas.width,canvas.height);
		savecanvasstate();
	});		
});