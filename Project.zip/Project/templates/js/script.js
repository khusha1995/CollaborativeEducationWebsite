var wx=0;
var wy=0;
var pchat=0;
var cy=400;
var cid=0;
var cxx=0;
var cyy=0;
var ctx,canvas,points,bufer,offset;
var action='up';
var pencil=2;
var eraser=10;
var mode='pencil';
var du='';
var window_focus = Math.floor(Date.now() / 1000);
var msgid=0;

function updatecanvasdata()
{
	$.ajax({
		url: '/templates/ajax_canvas.php',
		method: 'post',
		data:{pchat:pchat,lastid:cid}
	}).done(function(msg){
		var aa=JSON.parse(msg);
		for (var x in aa)
		{
			cid=aa[x].id;
			if (aa[x].action=='erase')
			{
				ctx.fillStyle="#FFFFFF";
				ctx.fillRect(0,0,canvas.width,canvas.height);
			}
			else if	(aa[x].action=='image')
			{
				var img = new Image;
				img.onload = function(){
					ctx.drawImage(img,0,0,canvas.width,canvas.height); // Or at whatever offset you like
				};
				img.src = aa[x].params;
			}
		}
	});
}

function initcanvas()
{
	canvas=document.getElementById('draw');
	ctx = canvas.getContext('2d');
	ctx.lineWidth = pencil;
	offset = 1000;
	ctx.shadowBlur = 0;
	ctx.shadowColor = "#000000";
	ctx.shadowOffsetX = -offset;
	ctx.fillStyle="#FFFFFF";
	ctx.fillRect(0,0,canvas.width,canvas.height);

	points = new Array();
	bufer = ctx.getImageData(0,0,canvas.width,canvas.height);
	
	updatecanvasdata();
}

function resize()
{
	if (wy>900)
	{
		cy=400;
	}
	else if (wy>500)
	{
		cy=200;
	}
	else
	{
		cy=100;
	}
	cid=0;
	$('#whiteboard').css('height',cy+'px').html('<div id="ccontainer"><canvas width="'+parseInt(cy*2)+'px" height="'+cy+'px" id="draw"></canvas></div>');
	$('#chat').css('height',(wy-cy-$('#write').height())+'px');
	if (wx<1000)
	{
		$('#center').css('width',wx+'px');
		if (wx>500)
		{
			$('#sendmsg').css('width',(wx-400)+'px');
			$('#accounts').css('height',(wy-cy)+'px').css('display','block');
			$('#chat').css('width',(wx-260)+'px');
		}
		else
		{
			$('#accounts').css('height',(wy-cy-$('#write').height())+'px').css('display','none');
			$('#sendmsg').css('width',(wx-50)+'px');
			$('#chat').css('width',wx+'px');
		}
	}
	else
	{
		$('#center').css('width','1000px');
		$('#chat').css('width','740px');
		$('#sendmsg').css('width','600px');
		$('#accounts').css('height',(wy-cy)+'px').css('display','block');
	}
	cxx=$('#draw').offset().left;
	cyy=$('#draw').offset().top;	
	initcanvas();
}
function openfilesdialog(pchat)
{
	$('#iframe').attr('src', '/templates/fileshist.php?pchat='+pchat);
	$('#iframebg').show();
	//window.open('/templates/fileshist.php?pchat='+pchat,'privatefiles_'+$(this).closest('.user').attr('user'),'status=no,resizable=yes,left=200,top=200,toolbar=no,menubar=no,scrollbars=no,location=no,directories=no,width=600,height=600,screenX=600,screenY=600'); 
	
}
function getusers()
{
	$.ajax({
		url: '/templates/ajax_accounts.php',
		method:'post',
		data:{pchat:pchat}
	}).done(function(msg){
		$('#accounts').html(msg);
		$('.useroptions .option[action=private]').click(function(){
			window.open('/templates/tchat.php?private='+$(this).closest('.user').attr('user'),'private_'+$(this).closest('.user').attr('user'));
		});
		$('.useroptions .option[action=sprivate]').click(function(){
			window.open('/templates/chat.php?private='+$(this).closest('.user').attr('user'),'private_'+$(this).closest('.user').attr('user'));
		});
		$('.useroptions .option[action=sendfile]').click(function(){
			openfilesdialog($(this).closest('.user').attr('user'));
		});
	});
}
function setprivate(s)
{
	pchat=s;
}
function submitmessage()
{
	$.ajax({
		url: '/templates/ajax_send.php',
		method: 'post',
		data:{msg:$('#sendmsg').val(),to:pchat}
	}).done(function(msg){
		$('#sendmsg').val('');
	});
}

$(document).ready(function(){
	
	wx=parseInt($(window).width());
	wy=parseInt($(window).height());
	resize();
	$(window).resize(function(){
		wx=parseInt($(window).width());
		wy=parseInt($(window).height());
		resize();
	});
	setInterval(function(){
		getusers();
	},4230);
	getusers();
	
	setInterval(function(){
		var focused=true;
		if (Math.floor(Date.now() / 1000)-window_focus>3) focused=false;
		$.ajax({
			url: '/templates/ajax_chat.php',
			method: 'post',
			data: {pchat:pchat,focused:focused}
		}).done(function(msg){
			if (msg=='offline') 
			{
				window.location.href='/';
			}
			else
			{
				$('#chat').html(msg);
				$('.message').each(function(){
					if (!$(this).hasClass('mine'))
					{
						var i=parseInt($(this).attr('msgid'));
						if (i>msgid)
						{
							msgid=i;
							document.getElementById('alrt').play();
						}
					}
				});
			}
	$('.message').each(function(){
        var str = $(this).html();
        var regex = /(https?:\/\/([-\w\.]+)+(:\d+)?(\/([\w\/_\.]*(\?\S+)?)?)?)/ig
        var replaced_text = str.replace(regex, "<a href='$1' target='_blank'>$1</a>");
        $(this).html(replaced_text);
    });
			
		});
	},1231);
	$('#sendmsgbutton').click(function(){
		submitmessage();
	});
	
	$('#iframecontainer #close').click(function(){
		$('#iframebg').hide();
	});
	$('.openhistfiles').click(function(){
		openfilesdialog(pchat);
		//window.open($(this).attr('href'),$(this).attr('target'),'status=no,resizable=yes,left=200,top=200,toolbar=no,menubar=no,scrollbars=no,location=no,directories=no,width=600,height=600,screenX=600,screenY=600'); 
		return false;
	});
	
	$('#sendmsg').keypress(function (e) {
		if (e.which == 13) {
			submitmessage();
		}
	});
	
	initcanvas();
	$('body').mousemove(function(e){
		window_focus = Math.floor(Date.now() / 1000);
	});
	$('body').mouseup(function(e){
		window_focus = Math.floor(Date.now() / 1000);
	});
	$('body').mousedown(function(e){
		window_focus = Math.floor(Date.now() / 1000);
	});
	$('body').keydown(function(e){
		window_focus = Math.floor(Date.now() / 1000);
	});
	$('body').keyup(function(e){
		window_focus = Math.floor(Date.now() / 1000);
	});
	
	setInterval(function(){
		updatecanvasdata();
	},1231);	
});