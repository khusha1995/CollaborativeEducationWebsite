<?php
	require('../gen.php');
	if ((isset($_POST['action']))&&($_POST['action']=='auth'))
	{
		if (USER_OK) die('true');
		die('false;'.l('Неверные логин или пароль'));
	}
	elseif ((isset($_POST['action']))&&($_POST['action']=='register'))
	{
		if (!preg_match('/^.+@.+\\.[^.]+$/uis',$_POST['register_login']))
		{
			die('false;'.l('Вы ввели неверный E-mail'));
		}
		if ($_POST['register_password1']!=$_POST['register_password2'])
		{
			die('false;'.l('Пароли не совпадают'));
		}
		if ($_POST['register_password1']=='')
		{
			die('false;'.l('Пароль не может быть пустым'));
		}
		$r=$db->query('SELECT id FROM users WHERE username="'.$db->real_escape_string($_POST['register_login']).'"');
		if ($p=$r->fetch_assoc())
		{
			die('false;'.l('Пользователь с такими данными уже существует'));
		}
		$db->query('INSERT INTO users SET name="'.$db->real_escape_string($_POST['register_name']).'", phone="'.$db->real_escape_string($_POST['register_phone']).'", username="'.$db->real_escape_string($_POST['register_login']).'", hash="'.md5($_POST['register_password1'].$_POST['register_login']).'", email="'.$db->real_escape_string($_POST['register_login']).'"');
		
		
		//Пользователю
				require_once('../phpmailer/class.phpmailer.php');
				require_once('../phpmailer/class.smtp.php');
				
				$mail_text='<strong>Добро пожаловать на сайт MAIKI.MD</strong>
						<p>Спасибо, что Вы зарегистрировались на нашем сайте со следующими регистрационными данными:</p>
						<table border="1px" cellspacing="0px" cellpadding="2px">
						<tr><td><strong>Имя</strong></td><td>'.$_POST['register_name'].'</td></tr>
						<tr><td><strong>Телефон</strong></td><td>'.$_POST['register_phone'].'</td></tr>
						<tr><td><strong>E-mail</strong></td><td>'.$_POST['register_login'].'</td></tr>
						<tr><td><strong>Пароль</strong></td><td>'.$_POST['register_password'].'</td></tr>
						</table>';
				$mail = new PHPMailer;
				$mail->CharSet = 'UTF-8';
				$mail->setFrom('info@maiki.md', 'Sales Maiki.md');
				$mail->AddAddress($_POST['register_login'],'Manager');
				$mail->Subject = 'Добро пожаловать на сайт Maiki.md';
				$mail->msgHTML($mail_text);
				$mail->AltBody = 'This is a plain-text message body';
				$mail->isSMTP(); // Set mailer to use SMTP
				$mail->SMTPAuth = true; // Enable SMTP authentication
				$mail->Host = 'smtp.yandex.ru'; // Specify main and backup SMTP servers
				$mail->Username = 'info@maiki.md'; // SMTP username
				$mail->Password = '079447735';
				if (!$mail->send()) {
					$result.="Mailer Error: " . $mail->ErrorInfo;
				} else {
					$result.="Message sent!";
				}
			
				$mail_text='<strong>Новый пользователь</strong>
						<table border="1px" cellspacing="0px" cellpadding="2px">
						<tr><td><strong>E-mail</strong></td><td>'.$_POST['register_login'].'</td></tr>
						<tr><td><strong>Имя</strong></td><td>'.$_POST['register_name'].'</td></tr>
						<tr><td><strong>Телефон</strong></td><td>'.$_POST['register_phone'].'</td></tr>
						</table>';
				require_once('../phpmailer/class.phpmailer.php');
				require_once('../phpmailer/class.smtp.php');
				$result='SELECT * FROM settings WHERE name="manager_emails"';
				$r=$db->query('SELECT * FROM settings WHERE name="manager_emails"');
				if ($e=$r->fetch_assoc())
				{
					$ea=preg_split('/[, ]+/uis',$e['value'],-1,PREG_SPLIT_NO_EMPTY);
					foreach ($ea as $email)
					{
						$mail = new PHPMailer;
						$mail->CharSet = 'UTF-8';
						$mail->setFrom('info@maiki.md', 'Sales Maiki.md');
						$mail->AddAddress($email,'Manager');
						$mail->Subject = 'Новый пользователь';
						$mail->msgHTML($mail_text);
						$mail->AltBody = 'This is a plain-text message body';
						$mail->isSMTP(); // Set mailer to use SMTP
						$mail->SMTPAuth = true; // Enable SMTP authentication
						$mail->Host = 'smtp.yandex.ru'; // Specify main and backup SMTP servers
						$mail->Username = 'info@maiki.md'; // SMTP username
						$mail->Password = '079447735';
						if (!$mail->send()) {
							$result.="Mailer Error: " . $mail->ErrorInfo;
						} else {
							$result.="Message sent!";
						}
					}
				}
				die('true;'.l('Вы успешно зарегистрировались на сайте MAIKI.MD'));
	}
	elseif ((isset($_POST['action']))&&($_POST['action']=='remind'))
	{
		$r=$db->query('SELECT id FROM users WHERE username="'.$db->real_escape_string($_POST['remind_login']).'"');
		if ($p=$r->fetch_assoc())
		{
			//die('false;'.l('Пользователь с такими данными уже существует'));
			$pass=substr(md5(microtime(true)),8);
			$db->query('UPDATE users SET hash="'.md5($pass.$_POST['remind_login']).'" WHERE id='.$p['id']);
		
		
			//Пользователю
				require_once('../phpmailer/class.phpmailer.php');
				require_once('../phpmailer/class.smtp.php');
				
				$mail_text='<strong>Сброс пароля на сайте MAIKI.MD</strong>
						<p>Вы воспользовались функцией сброса пароля. Ваши новые данные:</p>
						<table border="1px" cellspacing="0px" cellpadding="2px">
						<tr><td><strong>E-mail</strong></td><td>'.$_POST['remind_login'].'</td></tr>
						<tr><td><strong>Пароль</strong></td><td>'.$pass.'</td></tr>
						</table>
						Вы можете заменить Ваш пароль в личном кабинете.
						';
				$mail = new PHPMailer;
				$mail->CharSet = 'UTF-8';
				$mail->setFrom('info@maiki.md', 'Sales Maiki.md');
				$mail->AddAddress($_POST['remind_login'],'Manager');
				$mail->Subject = 'Сброс пароля на сайте Maiki.md';
				$mail->msgHTML($mail_text);
				$mail->AltBody = 'This is a plain-text message body';
				$mail->isSMTP(); // Set mailer to use SMTP
				$mail->SMTPAuth = true; // Enable SMTP authentication
				$mail->Host = 'smtp.yandex.ru'; // Specify main and backup SMTP servers
				$mail->Username = 'info@maiki.md'; // SMTP username
				$mail->Password = '079447735';
				if (!$mail->send()) {
					$result.="Mailer Error: " . $mail->ErrorInfo;
				} else {
					$result.="Message sent!";
				}
			
				die('true;'.l('Проверьте почту, пожалуйста'));
		}
		else
		{
				die('true;'.l('1Проверьте почту, пожалуйста'));
		}
	}
?>