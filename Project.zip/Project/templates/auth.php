<?php
	require('../gen.php');
	if (USER_OK)
	{
		header('Location: chat.php');
		die();
	}
?>
<!DOCTYPE html>
<head>
	<title>Login</title>
	<link rel="shortcut icon" href="images/login-icon-3049-16x16.ico" type="image/x-icon" />
	<link rel=stylesheet href="css/auth.css"/>
</head>
<body>
	<div class="auth">
		<form action="" method="post">
			<table>
				<tr><td>Username</td><td><input type="text" name="login"/></td></tr>
				<tr><td>Password</td><td><input type="password" name="password"/></td></tr>
				<tr><td colspan="2"><input type="submit" value="Log in"/></td></tr>
			</table>	
		</form>
	</div>
</body>