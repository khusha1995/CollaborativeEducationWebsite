<?php
	require('../gen.php');
	if (!USER_OK)
	{
		die('offline');
	}
	
	$ua=$db->query('SELECT * FROM users');
	$users=array();
	while ($u=$ua->fetch_assoc())
	{
		$users[$u['id']]=$u;
	}
	if ((isset($_POST['pchat']))&&($_POST['pchat']!=0))
	{
		$private=(int)$_POST['pchat'];
		$condition=' ((`to`='.USER_ID.' AND `from`='.$private.') OR (`from`='.USER_ID.' AND `to`='.$private.')) ';
		if ($_POST['focused']=='true')
		{
			$db->query('UPDATE chat SET `read`=1 WHERE `from`='.$private.' AND `to`='.USER_ID);
		}
		/*
		if (($_USER_PRIVS['teacher']->priv1&USER_PRIV1)==0)
		{
			$condition=' ((`to`='.USER_ID.' AND `from`='.$private.') OR (`from`='.USER_ID.' AND `to`='.$private.')) ';
		}
		else
		{
			$ua=$db->query('SELECT * FROM users WHERE id='.$private);
			if ($u=$ua->fetch_assoc())
			{
				if (($_USER_PRIVS['teacher']->priv1&$u['priv1'])==0)
				{
					$condition=' ((`to`='.USER_ID.' AND `from`='.$private.') OR (`from`='.USER_ID.' AND `to`='.$private.')) ';
				}
				else
				{
					die();
				}
			}
			else
			{
				die();	
			}
		}*/
	}
	else
	{
		$condition=' `to`=0 ';
	}
	
	$lastid=0;
	$aa=$db->query('SELECT * FROM chat WHERE '.$condition.' ORDER BY `date` DESC LIMIT 100');
	while ($a=$aa->fetch_assoc())
	{
		($a['from']==USER_ID)?$mine='mine':$mine='';
		if ($a['type']=='file')
		{
			echo '<div class="message file '.$mine.'" msgid="'.$a['id'].'"><div class="container">
					<div class="text">Attachment: <a href="/templates/file.php?id='.$a['id'].'" target="_blank">'.$a['message'].'</a></div>
					<div class="name">'.$users[$a['from']]['name'].'</div>
					<div class="date">'.$a['date'].'</div>
				</div></div>';
		}
		else
		{
			echo '<div class="message '.$mine.'" msgid="'.$a['id'].'"><div class="container">
					<div class="text">'.$a['message'].'</div>
					<div class="name">'.$users[$a['from']]['name'].'</div>
					<div class="date">'.$a['date'].'</div>
				</div></div>';
		}
		$lastid=$a['id'];
	}
	$db->query('DELETE FROM chat WHERE '.$condition.'  AND id<'.$lastid);
?>