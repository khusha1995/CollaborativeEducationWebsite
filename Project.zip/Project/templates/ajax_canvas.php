<?php
	require('../gen.php');
	if (!USER_OK)
	{
		die();
	}
	
	//clean logged out teachers whiteboard
	$ta=$db->query('SELECT * FROM users WHERE priv1&'.$_USER_PRIVS['teacher']->priv1.'>0');
	while ($t=$ta->fetch_assoc())
	{
		if (microtime(true)-strtotime($t['activity'])>10)
		{
			$db->query('DELETE FROM whiteboard WHERE `from`='.$t['id']);
		}
	}
	
	$lastid=(int)$_POST['lastid'];
	$ua=$db->query('SELECT * FROM users');
	$users=array();
	while ($u=$ua->fetch_assoc())
	{
		$users[$u['id']]=$u;
	}
	
	$private=(int)$_POST['pchat'];
	if ($private==0)
	{
		$condition=' `to`=0 ';
	}
	else
	{
		$condition=' ((`to`='.USER_ID.' AND `from`='.$private.') OR (`from`='.USER_ID.' AND `to`='.$private.')) ';
	}
	
	$actions=array();
	$ia=$db->query('SELECT * FROM whiteboard WHERE '.$condition.' AND `action`="image" ORDER BY `id` DESC LIMIT 1');
	$i=$ia->fetch_assoc();
	if (!$i)
	{
		$actions[]=array('action'=>'erase','params'=>'');
		$db->query('DELETE FROM whiteboard WHERE '.$condition);
	}
	elseif ($i['id']>$lastid)
	{
		$db->query('DELETE FROM whiteboard WHERE '.$condition.' AND id<'.$i['id']);
		$aa=$db->query('SELECT * FROM whiteboard WHERE '.$condition.' AND id>='.$i['id'].' ORDER BY `id` ASC');
		while ($a=$aa->fetch_assoc())
		{
			$actions[]=array('id'=>$a['id'],'action'=>$i['action'],'params'=>$i['params']);
		}
	}
	else
	{
		$db->query('DELETE FROM whiteboard WHERE '.$condition.' AND id<'.$i['id']);
		$aa=$db->query('SELECT * FROM whiteboard WHERE '.$condition.' AND id>'.$lastid.' ORDER BY `id` ASC');
		while ($a=$aa->fetch_assoc())
		{
			$actions[]=array('id'=>$a['id'],'action'=>$i['action'],'params'=>$i['params']);
		}
	}
	echo json_encode($actions);
?>