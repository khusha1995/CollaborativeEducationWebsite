<?php
	require('../gen.php');
	if (!USER_OK)
	{
		die();
	}
	
	if (isset($_POST['msg']))
	{
		(isset($_POST['to']))?$to=(int)$_POST['to']:$to=0;
		(isset($_POST['private']))?$private=1:$private=0;
		(isset($_POST['type']))?$type=$db->escape_string($_POST['type']):$type='message';
		$msg=$db->escape_string($_POST['msg']);
		
		$db->query('INSERT INTO chat SET `date`=NOW(), `from`='.USER_ID.', `to`='.$to.',`private`='.$private.',`type`="'.$type.'",`message`="'.$msg.'"');
	}
?>