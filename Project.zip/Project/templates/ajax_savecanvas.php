<?php
	require('../gen.php');
	if (!USER_OK)
	{
		die();
	}
	if (($_USER_PRIVS['teacher']->priv1&USER_PRIV1)!=0)
	{
		if (isset($_POST['action']))
		{
			$db->query('INSERT INTO whiteboard SET `from`='.USER_ID.', `to`='.((int)$_POST['pchat']).', action="'.$db->escape_string($_POST['action']).'", params="'.$db->escape_string($_POST['params']).'"');
		}
	}
?>