<?php
	require('../gen.php');
	if (!USER_OK)
	{
		header('Location: /templates/auth.php');
		die();
	}
	if (($_USER_PRIVS['admin']->priv1&USER_PRIV1)!=0)
	{
		header('Location: /doit/users.php');
		die();
	}
	elseif (($_USER_PRIVS['teacher']->priv1&USER_PRIV1)==0)
	{
		header('Location: /templates/chat.php');
		die();
	}
	
	if (isset($_GET['private']))
	{
		$private=(int)$_GET['private'];
		$ua=$db->query('SELECT * FROM users WHERE id='.$private);
		if ($u=$ua->fetch_assoc())
		{
			$chatname=$u['name'].' private chat';
		}
		else
		{
			$chatname='Chat';
			$private=0;
		}
	}
	else
	{
		$private=0;
		$chatname='Chat';
	}		
	
	if (isset($_FILES['upload']))
	{
		foreach ($_FILES['upload']['name'] as $fk=>$fv)
		{
			$db->query('INSERT INTO chat SET `date`=NOW(), `from`='.USER_ID.', `to`='.$private.', `type`="file", message="'.$fv.'"');
			$fname=md5($db->insert_id);
			move_uploaded_file($_FILES['upload']['tmp_name'][$fk],ROOT.'/uploads/'.$fname);
		}
		header('Location: /templates/tchat.php?private='.$private);
		die();
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $chatname; ?> (teacher chat)</title>
	<meta name="viewport" content="width=device-width, initial-scale=1" charset="UTF-8">
	<link rel="stylesheet" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.css">
	<link rel="stylesheet" href="/templates/css/style.css">
	<link rel="shortcut icon" href="images/Chat-50.ico" type="image/x-icon" />
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	
	<!--Send Email-->
	<link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Montserrat:400,700'>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
	<script type="text/javascript" src="http://code.jquery.com/jquery-1.7.2.min.js"></script>
	
	<!--Custom Scripts-->
	<script type="text/javascript" src="/templates/js/jquery.js"></script>
	<script type="text/javascript" src="/templates/js/script_teacher.js"></script>
	
	<!--Quill-->
	<link href="https://cdn.quilljs.com/1.0.0/quill.snow.css" rel="stylesheet">
	<script src="https://cdn.quilljs.com/1.0.0/quill.js"></script>
</head>
	
<body>
	<audio id="alrt" src="/templates/audio/communication-channel.mp3" type="audio/mpeg" preload="auto"></audio>
	<div id="iframebg">
		<div id="iframecontainer">
			<div id="close">
				<input type="image" id="Exitbutton" img src="images/iframe/close-box.png"/>
			</div>
			<iframe id="iframe" width="900px" height="600px" frameBorder="0px"></iframe>
		</div>
	</div>
	<div id="logout">
		<a href="http://jlearning.co.uk/templates/auth.php?logout=1">
		<input type="image" id="logoffbutton" src="images/logoutt.png"/></a>
	</div>
	<div id="drawfunctions">
		<div class="function draw active" action="draw"><img src="images/pencil.png"/></div>
		<div class="function erase" action="erase"><img src="images/eraser.png"/></div>
		<div class="function eraseall" action="eraseall"><img src="images/whitebox.png"/></div>
	</div>
	<div id="whiteboard"></div>
	<div id="workspace">
	<div id="pollSlider-button"></div>
		<div class="container1">
			<div class="left">
				<div id="editor-container"></div>
			</div>
		</div>
	<div id="center">
		<div id="accounts"></div>
		<div id="chat"></div>
		<div id="write">
			<input type="image" img src="images/upload.png" a href="/templates/fileshist.php?pchat=<?=$private?>" target="privatefiles_<?=$private?>" class="openhistfiles" </input>
			<input type="text" id="sendmsg" placeholder="Type a message here..." />
			<input type="image" id="sendmsgbutton" class="sendbutton" img src="images/send-arrow.png" />
		</div>
	</div>
	</div>
	<?php
		if (isset($_GET['private']))
		{
			$private=(int)$_GET['private'];
			echo '<script type="text/javascript">
					setprivate('.$private.');
				</script>';
		}
	?>
	<footer class="footer">
		<div class="container">
			<div id="right">
				<div class="foot">
					<div class="login-block">
						<form method="post" action="">    <!--flipMail API to send emails from html to mail -->
						<h1>need the tutor to come online? - Email her</h1>
						<input type="text" id="name" name='name' placeholder="Username"/>
						<input type="text" id="subject" name='subject' placeholder="Subject"/>
						<input type="text" id="email" name='email' placeholder="Email Address:"/>
						<textarea id="message" name='message' cols="43" rows="5" placeholder="Type your message here"></textarea>
					<br><br>
						<button>Submit</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</footer>
</body>
</html>