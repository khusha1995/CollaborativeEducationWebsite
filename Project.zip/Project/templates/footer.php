					</td>
				</tr>
			</table>
		</div>
		<div id="footer">
			<div class="center">
				<table class="footer_table">
					<tr>
						<td class="logo2"><img src="/templates/images/<?=file_exists(ROOT.'/templates/images/logo2_'.$_SESSION['language'].'.png')?'logo2_'.$_SESSION['language'].'.png':'logo2_ro.png'?>"/>
							<div class="phone"><?=l('Телефон')?></div>
							<div class="mail"><?=l('E-mail footer')?></div>
						</td>
						<td class="footer_products">
							<div class="header"><?=l('Наши товары');?></div>
							<?php
								$r=$db->query('SELECT catalog_structure.alias, catalog_structure.name, catalog_structure.img FROM catalog_structure WHERE parent_id IN (SELECT id FROM catalog_structure WHERE alias="top" AND lang="ru") AND lang="ru" ORDER BY prior');
								if ($r) while ($c=$r->fetch_assoc())
								{
									echo '<div class="item '.$class.'"><a href="/templates/catalog.php?top='.urlencode($c['alias']).'">'.$c['name'].'</a></div>';
								}
							?>
						</td>
						<td class="footer_articles">
							<div class="header"><?=l('Наша компания');?></div>
							<?php
								$r=$db->query('SELECT articles_articles.* FROM articles_articles, articles_articles_structure WHERE articles_articles_structure.article=articles_articles.id AND articles_articles_structure.structure IN (SELECT id FROM articles_structure WHERE alias="about" AND lang="ru")');
								
								if ($r) while ($c=$r->fetch_assoc())
								{
									echo '<div class="item '.$class.'"><a href="/templates/article.php?id='.$c['id'].'">'.$c['name'].'</a></div>';
								}
								echo '<div class="item '.$class.'"><a href="/templates/tables.php">'.l('Таблицы размеров').'</a></div>';
							?>
						</td>
						<a name="footer"></a>
						<td class="footer4">
							<p class="header"><?=l('Subscribing');?></p>
							<form action="#footer" method="post">
								<input type="text" name="subscribe_email" placeholder="<?=l('Введите ваш e-mail')?>" value="<?=$_POST['subscribe_email']?>"/>
								<input type="submit" name="subscribe_submit" value="<?=l('Подписаться')?>"/>
							</form>
							
							<p class="header"><?=l('Follow us');?></p>
							<div class="social">
								<?=l('Социальные ссылки')?>
							</div>
						</td>
				</table>
			</div>
		</div>
	</div>	
	<script type="text/javascript" src="/templates/js/script.js"></script>
<?php
	if (isset($_POST['subscribe_email']))
	{
		if (preg_match('/^[^@]+@[^@]+\\.[^@]+$/uis',$_POST['subscribe_email']))
		{
			$r=$db->query('SELECT id FROM subscribers WHERE email="'.$db->escape_string($_POST['subscribe_email']).'"');
			if ($r) 
			{
				if ($c=$r->fetch_assoc())
				{
					echo '<script>
						$(document).ready(function(){
							alert(\''.l('Вы уже подписаны на новости').'\');
						});
						</script>';
				}
				else
				{
					$db->query('INSERT INTO subscribers SET email="'.$db->escape_string($_POST['subscribe_email']).'"');
					echo '<script>
						$(document).ready(function(){
							alert(\''.l('Теперь Вы подписаны на новости. Спасибо!').'\');
						});
						</script>';
				}
			}
		}
		else
		{
			echo '<script>
					$(document).ready(function(){
						alert(\''.l('Вы ввели неверный e-mail').'\');
					});
					</script>';
			
		}
	}
?>
					<div class="popup_bg popup_login"></div>
						<div class="popup_content popup_login">
								<div class="close"></div>
								<div class="header"><?=l('Войти')?></div>
								<div class="clear"></div>
								<form action="" method="post">
									<input type="text" name="login" placeholder="<?=l('E-mail')?>"/>
									<input type="password" name="password" placeholder="<?=l('Пароль')?>"/>
									<div class="remember remindlink"><?=l('Забыли пароль')?></div>
									<input type="submit" value="<?=l('Войти')?>"/>
									<div class="register registerlink"><?=l('У меня нет аккаунта. Регистрация')?></div>
									<div class="alternative">
										<div class="container"><span><?=l('или войти')?></span></div>
									</div>
									<div class="social facebook"><?=l('Через Facebook')?></div>
									<div class="social vk"><?=l('Через VKontakte')?></div>
								</form>
						</div>
						
						<div class="popup_bg popup_remind"></div>
						<div class="popup_content popup_remind">
								<div class="close"></div>
								<div class="header"><?=l('Восстановить пароль')?></div>
								<div class="clear"></div>
								<form action="" method="post">
									<input type="text" name="remind_login" placeholder="<?=l('E-mail')?>"/>
									<input type="submit" value="<?=l('Восстановить')?>"/>
								</form>
						</div>
						
						<div class="popup_bg popup_register"></div>
						<div class="popup_content popup_register">
								<div class="close"></div>
								<div class="header"><?=l('Регистрация')?></div>
								<div class="clear"></div>
								<form action="" method="post">
									<input type="text" name="register_name" placeholder="<?=l('Вас зовут')?>"/>
									<input type="text" name="register_phone" placeholder="<?=l('Ваш телефон')?>"/>
									<input type="text" name="register_login" placeholder="<?=l('E-mail')?>"/>
									<input type="password" name="register_password1" placeholder="<?=l('Пароль')?>"/>
									<input type="password" name="register_password2" placeholder="<?=l('Пароль ещё раз')?>"/>
									<input type="submit" value="<?=l('Зарегистрироваться')?>"/>
									<div class="login loginlink"><?=l('У меня есть аккаунт. Войти')?></div>
									<div class="alternative">
										<div class="container"><span><?=l('или зарегистрироваться')?></span></div>
									</div>
									<div class="social facebook"><?=l('Через Facebook')?></div>
									<div class="social vk"><?=l('Через VKontakte')?></div>
								</form>
						</div>
	<!--Start of Tawk.to Script-->
		<script type="text/javascript">
			var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
			(function(){
				var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
				s1.async=true;
				s1.src='https://embed.tawk.to/579093e00e63b04e4ae417c9/default';
				s1.charset='UTF-8';
				s1.setAttribute('crossorigin','*');
				s0.parentNode.insertBefore(s1,s0);
			})();
		</script>
	<!--End of Tawk.to Script-->
</body>