<?php
	require('../gen.php');
	if (!USER_OK)
	{
		die();
	}
	if (($_USER_PRIVS['teacher']->priv1&USER_PRIV1)!=0)
	{
		$menu='<div class="useroptions">
				<div class="option" action="sendfile">Send file</div>
				<div class="option" action="private">Private message</div>
			</div>';
	}
	else
	{
		$menu='';
	}
	
	if ((isset($_POST['pchat']))&&($_POST['pchat']!=0))
	{
		$private=(int)$_POST['pchat'];
		$condition=' id='.$private.' ';
		/*
		if (($_USER_PRIVS['teacher']->priv1&USER_PRIV1)!=0)
		{
			$condition=' id='.$private.' ';
		}
		else
		{
			$ua=$db->query('SELECT * FROM users WHERE id='.$private);
			if ($u=$ua->fetch_assoc())
			{
				if (($_USER_PRIVS['teacher']->priv1&$u['priv1'])!=0)
				{
					$condition=' id='.$private.' ';
				}
				else
				{
					$condition=' false ';
				}
			}
			else
			{
				$condition=' false ';
			}
		}*/
	}
	else
	{
		$condition=' id<>'.USER_ID.' AND (priv1=0 OR priv1&'.$_USER_PRIVS['teacher']->priv1.'>0 ) ';
	}
	
	$aa=$db->query('SELECT * FROM users WHERE '.$condition.' ORDER BY name ');
	while ($a=$aa->fetch_assoc())
	{
		$mm=$db->query('SELECT * FROM chat WHERE `from`='.$a['id'].' AND `to`='.USER_ID.' AND `read`=0 LIMIT 1'); 
		if ($m=$mm->fetch_assoc())
		{
			$unread=' unread ';
		}
		else
		{
			$unread='';
		}
		if ((($_USER_PRIVS['teacher']->priv1&USER_PRIV1)==0)&&(($_USER_PRIVS['teacher']->priv1&$a['priv1'])!=0))
		{
			$menu='<div class="useroptions">
					<div class="option" action="sprivate">Send files</div>
					<div class="option" action="sprivate">Private message</div>
				</div>';
		} 
		else if ((($_USER_PRIVS['teacher']->priv1&USER_PRIV1)==0)&&(($_USER_PRIVS['teacher']->priv1&$a['priv1'])==0))
		{
			$menu='<div class="useroptions">
					<div class="option" action="sprivate">Private message</div>
				</div>';
		}
		$tm=strtotime($a['activity']);
		(microtime(true)-$tm<11)?$status='online':$status='offline';
		echo '<div class="user '.$status.' '.$unread.'" user="'.$a['id'].'">'.$menu.$a['name'].'</div>';
	}
?>