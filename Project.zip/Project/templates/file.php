<?php
	require('../gen.php');
	if (!USER_OK)
	{
		die();
	}
	
	if (isset($_GET['id']))
	{
		$id=(int)$_GET['id'];
		$fa=$db->query('SELECT * FROM chat WHERE id='.$id.' AND type="file" AND (`to`=0 OR `to`='.USER_ID.' OR `from`='.USER_ID.') LIMIT 1');
		while ($f=$fa->fetch_assoc())
		{
			header('Content-Type: application/octet-stream');
			header("Content-Transfer-Encoding: Binary"); 
			header("Content-disposition: attachment; filename=\"" .$f['message']. "\"");
			readfile(ROOT.'/uploads/'.md5($id));
		}
	}
?>