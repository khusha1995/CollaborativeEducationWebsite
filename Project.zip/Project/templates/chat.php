<?php
	require('../gen.php');
	if (!USER_OK)
	{
		header('Location: /templates/auth.php');
		die();
	}
	if (($_USER_PRIVS['admin']->priv1&USER_PRIV1)!=0)
	{
		header('Location: /doit/users.php');
		die();
	}
	elseif (($_USER_PRIVS['teacher']->priv1&USER_PRIV1)!=0)
	{
		header('Location: /templates/tchat.php');
		die();
	}
	
	if (isset($_GET['private']))
	{
		$private=(int)$_GET['private'];
		$ua=$db->query('SELECT * FROM users WHERE id='.$private);
		if ($puser=$ua->fetch_assoc())
		{
			$chatname=$puser['name'].' private chat';
		}
		else
		{
			$chatname='Chat';
			$private=0;
		}
	}
	else
	{
		$private=0;
		$chatname='Chat';
	}		
	
	if ((isset($_FILES['upload']))&&($private!=0))
	{
		$ua=$db->query('SELECT * FROM users WHERE id='.$private);
		if ($u=$ua->fetch_assoc())
		{
			if (($_USER_PRIVS['teacher']->priv1&$u['priv1'])!=0)
			{
				foreach ($_FILES['upload']['name'] as $fk=>$fv)
				{
					$db->query('INSERT INTO chat SET `date`=NOW(), `from`='.USER_ID.', `to`='.$private.', `type`="file", message="'.$fv.'"');
					$fname=md5($db->insert_id);
					move_uploaded_file($_FILES['upload']['tmp_name'][$fk],ROOT.'/uploads/'.$fname);
				}
				header('Location: /templates/chat.php?private='.$private);
				die();
			}
		}
	}
?>
<!DOCTYPE html>
<head>
	<title><?php echo $chatname;?></title>
	<link rel="stylesheet" href="/templates/css/style_stud.css">
	<link rel="shortcut icon" href="images/Chat-50.ico" type="image/x-icon" />
	<script type="text/javascript" src="/templates/js/jquery.js"></script>
	<script type="text/javascript" src="/templates/js/script.js"></script>
</head>
<body>
	<audio id="alrt" src="/templates/audio/communication-channel.mp3" type="audio/mpeg" preload="auto"></audio>
	<div id="logout">
		<a href="http://jlearning.co.uk/templates/auth.php?logout=1">
		<input type="image" id="logoffbutton" src="images/logoutt.png"/></a>
	</div>
	<div id="whiteboard"></div>
	<div id="workspace">
		<div id="center">
			<div id="accounts"></div>
			<div id="chat"></div>
			<div id="write">
				<?php
					if (($_USER_PRIVS['teacher']->priv1&$puser['priv1'])!=0)
					{
						echo '<div class="files">
								<form action="" method="post" enctype="multipart/form-data">
									Send files: <input type="file" name="upload[]" multiple="true" min="1" max="9999"/> <input type="submit" value="Send Files"/>
								</form>
							</div>';
					}
				?>
				<input type="text" id="sendmsg" placeholder="Type a message here"/> <input type="image" id="sendmsgbutton" class="sendbutton" img src="images/send-arrow.png"/>
			</div>
		</div>
	</div>
	<?php
		if (isset($_GET['private']))
		{
			$private=(int)$_GET['private'];
			echo '<script type="text/javascript">
					setprivate('.$private.');
				</script>';
		}
	?>
</body>