<?php
	require('../gen.php');
	if ((!USER_OK)||(($_USER_PRIVS['teacher']->priv1&USER_PRIV1)==0))
	{
		die();
	}
	
	$ua=$db->query('SELECT * FROM users');
	$users=array();
	while ($u=$ua->fetch_assoc())
	{
		$users[$u['id']]=$u;
	}
	
	if (isset($_GET['pchat']))
	{
		$private=(int)$_GET['pchat'];
	}
	else
	{
		$private=0;
	}
	
	if (isset($_FILES['upload']))
	{
		foreach ($_FILES['upload']['name'] as $fk=>$fv)
		{
			$db->query('INSERT INTO chat SET `date`=NOW(), `from`='.USER_ID.', `to`='.$private.', `type`="file", message="'.$fv.'"');
			$fname=md5($db->insert_id);
			move_uploaded_file($_FILES['upload']['tmp_name'][$fk],ROOT.'/uploads/'.$fname);
		}
		header('Location: /templates/fileshist.php?pchat='.$private);
		die();
	}
	
	if ((isset($_GET['pchat']))&&($_GET['pchat']!=0))
	{
		$private=(int)$_GET['pchat'];
		if (($_USER_PRIVS['teacher']->priv1&USER_PRIV1)==0)
		{
			$condition=' ((`to`='.USER_ID.' AND `from`='.$private.') OR (`from`='.USER_ID.' AND `to`='.$private.')) ';
		}
		else
		{
			$ua=$db->query('SELECT * FROM users WHERE id='.$private);
			if ($u=$ua->fetch_assoc())
			{
				if (($_USER_PRIVS['teacher']->priv1&$u['priv1'])==0)
				{
					$condition=' ((`to`='.USER_ID.' AND `from`='.$private.') OR (`from`='.USER_ID.' AND `to`='.$private.')) ';
				}
				else
				{
					die();
				}
			}
			else
			{
				die();	
			}
		}
	}
	else
	{
		$condition=' `to`=0 ';
	}
	
	$aa=$db->query('SELECT * FROM chat WHERE '.$condition.' AND `type`="file" ORDER BY `date` DESC LIMIT 100');
	echo '<head><title>'.$users[$private]['name'].' FILES</title></head><body><center><form action="" method="post" enctype="multipart/form-data">
			Send files: <input type="file" name="upload[]" multiple="true" min="1" max="9999"/> <input type="submit" value="Send Files"/>
		</form><table border="1px" cellspacing="0px" cellpadding="3px"><thead><tr><td>name: </td><td>sender: </td><td>size: </td><td>type: </td></tr></thead>';
	while ($a=$aa->fetch_assoc())
	{
		echo '<tr><td><a href="/templates/file.php?id='.$a['id'].'" target="_blank">'.$a['message'].'</a></td><td>'.$users[$a['from']]['name'].'</td><td>'.filesize(ROOT.'/uploads/'.md5($a['id'])).'</td><td>'.strtoupper(preg_replace('/^.+\\.([^.]+)$/uis','$1',$a['message'])).'</td></tr>';
	}
	echo '</table></center></body>';
?>