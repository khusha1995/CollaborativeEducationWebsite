<?php
	if ((!USER_OK)||(($_USER_PRIVS['admin']->priv1&USER_PRIV1)==0))
	{	
		header('Location: auth.php');
		die();
	}
?>
<!DOCTYPE html>
<head>
	<title><?=$title?></title>
	<link rel="stylesheet" href="css/style.css">
	<script type="text/javascript" src="js/jquery-1.12.2.min.js"></script>
	<script type="text/javascript" src="js/tinymce/tinymce.min.js"></script>
</head>
<body>
<div class="menus">
	<p class="menu"><a href="users.php">Users</a></p>
	<p class="menu"><a href="index.php?logout=1">Log out</a></p>
</div>
<div class="content">
