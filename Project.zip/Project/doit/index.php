<?php
	require('../gen.php');
	if (!USER_OK)
	{
		header('Location: auth.php');
		die();
	}
	header('Location: users.php');
	die();
?>