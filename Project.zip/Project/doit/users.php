<?php
	require('../gen.php');
	
	if ((USER_PRIV1&$_USER_PRIVS['admin']->priv1)>0)
	{
		if (isset($_GET['logoutall']))
		{
			$db->query('UPDATE users SET `online`=0 WHERE NOT (priv1&'.$_USER_PRIVS['admin']->priv1.'>0)');
			header('Location: users.php');
			die();
		}
		if (isset($_POST['add_name']))
		{
			$name=$db->escape_string($_POST['add_name']);
			$username=$db->escape_string($_POST['add_username']);
			$hash=$db->escape_string(md5($_POST['add_password'].$_POST['add_username']));
			$priv1=0;
			if (isset($_POST['add_priv1']))
			{
				foreach ($_POST['add_priv1'] as $p)
				{
					$priv1=$priv1|$p;
				}
			}
			$db->query('INSERT INTO users SET name="'.$name.'", username="'.$username.'", hash="'.$hash.'", priv1='.$priv1.', active=0');
			header('Location: users.php');
			die();
		}
		if (isset($_POST['edit_id']))
		{
			$id=(int)$_POST['edit_id'];
			
			$name=$db->escape_string($_POST['edit_name']);
			if (($_POST['edit_username']!='')&&($_POST['edit_password']!=''))
			{
				$username=$db->escape_string($_POST['edit_username']);
				$hash=$db->escape_string(md5($_POST['edit_password'].$_POST['edit_username']));
				$hashedit=' username="'.$username.'", hash="'.$hash.'", ';
			}
			$priv1=0;
			if (isset($_POST['edit_priv1']))
			{
				foreach ($_POST['edit_priv1'] as $p)
				{
					$priv1=$priv1|$p;
				}
			}
			
			$db->query('UPDATE users SET name="'.$name.'", '.$hashedit.' priv1='.$priv1.', active=0 WHERE id='.$id);
			header('Location: users.php');
		}
		if (isset($_GET['del']))
		{
			$db->query('DELETE FROM users WHERE id='.((int)$_GET['del']));
			header('Location: users.php');
			die();
		}
		$title='Users';
		require('header.php');
	
		echo '<form action="users.php" method="post" enctype="multipart/form-data">';
		echo '<table>
			<tr><td>Name</td><td><input type="text" name="add_name" /></td></tr>
			<tr><td>Username</td><td><input type="text" name="add_username" /></td></tr>
			<tr><td>Password</td><td><input type="text" name="add_username" /></td></tr>
			<tr><td>Type</td><td>';
		
		$privs=array();
		$ra=$db->query('SELECT * FROM users_privs');
		while ($r=$ra->fetch_assoc())
		{
			$privs[]=$r;
			echo '<label><input type="checkbox" name="add_priv1[]" value="'.$r['priv1'].'"/> '.$r['name'].'</label><br/>';
		}
		echo '</td></tr>
			<tr><td colspan="2"><input type="submit" value="Add user"/></td></tr>
			</table></form>';
		echo 'Users: <div class="onlineusers"></div> 
			<a href="users.php?logoutall" onClick="javascript:{return confirm(\'Are You sure?\');}"/>Log out all</a>
			<table>';
		$r=$db->query('SELECT * FROM users');
		$onlinec=0;
		while ($l=$r->fetch_assoc())
		{
			if ($l['online']==1) $onlinec++;
			($l['online']==1)?$online='<div style="color:green;">Online</div>':$online='<div style="color:grey;">Offline</div>';
			echo '<tr><form action="users.php" method="post"><input type="hidden" name="edit_id" value="'.$l['id'].'"/>
					<td>'.$online.'</td>
					<td><input type="text" name="edit_name" value="'.htmlspecialchars($l['name']).'"/></td>
					<td><input type="text" name="edit_username" value="'.htmlspecialchars($l['username']).'"/></td>
					<td><input type="text" name="edit_password"/></td>
					<td>';
			foreach ($privs as $p)
			{
				(($l['priv1']&$p['priv1'])!=0)?$checked='checked':$checked='';
				echo '<label><input type="checkbox" '.$checked.' name="edit_priv1[]" value="'.$p['priv1'].'"/> '.$p['name'].'</label>&nbsp;&nbsp;';
			}
			echo '</td>
					<td><input type="submit" value="Save"/> <a href="users.php?del='.$l['id'].'" onClick="javascript:{return confirm(\'Really delete?\');}">Remove</a></td>
					</form></tr>';
		}
		echo '<script type="text/javascript">
				$(\'.onlineusers\').html(\''.$onlinec.' onine users\');
			</script>
			</table></div></body>';
	}
	else
	{
		if (!USER_OK)
	{
		header('Location: /templates/auth.php');
		die();
	}
		echo 'NO PRIVILEGIES FOR OPERATION';
	}
?>