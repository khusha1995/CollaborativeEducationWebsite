<?php
	header("Content-type: text/html; charset=utf-8");
	session_start();
	
	define('ROOT',__DIR__);
	
	$db= mysqli_connect('', '', '', ''); 
	if (!$db) { 
		die("Unable to connect to the database. Error code: ".mysqli_connect_error()); 
	}
	$db->query('set names utf8');
	
	foreach (glob(ROOT.'/autostart/*.php') as $filename)
	{
		require($filename);
	}
?>